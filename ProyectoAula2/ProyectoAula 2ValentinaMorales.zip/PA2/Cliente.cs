﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PA2
{
    internal class Cliente
    {
        public string Cedula { get; set; }
        public int Estrato { get; set; }
        public int MetaAhorro { get; set; }
        public int ConsumoActualEnergia { get; set; }
        public int ConsumoActualAgua { get; set; }
    }
}